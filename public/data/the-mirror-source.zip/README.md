# The Mirror · 认知回声室

The Mirror 让你用同一个问题比较三组提问。网站默认播放真实模型的预计算记录。每条记录可导出完整消息、原始回答、模型版本、参数与运行环境。

[English README](README.en.md) · [模型卡片](research/model-card.md) · [数据清单](research/dataset-manifest.json)

## 运行

需要 Node.js 20+ 和 Python 3.10–3.12。仅播放回放时，只需前端。

```sh
npm ci
npm run dev
```

前端默认访问 `http://localhost:3000`。连接自定义问题所需的实时推理服务。

```sh
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
uvicorn mirror.api:app --host 127.0.0.1 --port 8000
```

在网页的「模型设置」中填写 FastAPI 地址，工作台选择「实时推理」。本地推理首次加载固定版本的 Qwen 权重。原始和提示词基线使用同一个模型，LoRA 读取 `research/adapter`。每次成功的实时运行都会写入 `runs/experiments.sqlite`，页面也保存最近 60 次运行供浏览。

自定义模型需要支持 OpenAI 风格的 `POST /chat/completions`，并在模型设置中填写基础 URL、模型 ID 和所需的密钥。用 `MIRROR_API_ENDPOINTS` 配置允许访问的基础 URL，逗号分隔，默认 `https://api.openai.com/v1`。密钥仅用于转发，不写入数据库或浏览器存储。

静态部署可运行 `npm run build`，将 `out/` 发布至任意静态主机。默认回放从站内的 `public/data/` 读取。实际推理由独立 FastAPI 提供。连接网络上的推理服务时，部署与该站点可访问的 HTTPS 服务，并以 `MIRROR_ORIGINS` 设置站点的确切来源。本地服务默认绑定回环地址。

## 四种实验

| 模式 | 实验条件 |
|---|---|
| 立场切换 | 三个独立会话共用完整问题，分别附加立场 A、不附加立场、附加立场 B |
| 社会压力 | 保留模型真实的首答，随后加入质疑和权威主张，逐轮观察 |
| 证据更新 | 从同一个真实首答分支，一路加入未经核实的主张，另一路加入明确的新事实 |
| 提示词盲测 | 随机排列真实回答，用户先选，再显示来源和 Prompt |

镜像模式用词集合重合度对齐两侧句子。标注仅反映措辞。盲测可受回答中出现的立场线索影响。公开题目中假定的新证据由预设给定，自定义实验由用户确认新事实。

## 复现研究

```sh
python -m mirror.generate --seed 42
python -m mirror.train --data data/train.jsonl --steps 120 --batch-size 2 --precision bfloat16
for variant in base prompted lora; do
  python -m mirror.record --variant "$variant" --precision bfloat16 --tokens 160
done
python -m mirror.evaluate --per-group 1 --tokens 20 --batch-size 14 --precision bfloat16 --numeric-only
```

合成数据包含 20 个题型族、2,000 道基础题和 14,000 条对话。每道题覆盖七种条件。训练集有 1,500 道题 / 10,500 条对话，测试集有 500 道题 / 3,500 条对话，并按题型族整体留出。SymPy、固定 Python 表达式和确定性规则计算标准答案；无任意代码执行。每个 split 的校验和记录在 `data/manifest.json`。

已发布的评测为 CPU 小样本试验。去掉 `--per-group` 可运行完整留出评测。实测的单题 Prompt 和输出在 `research/benchmark-*.jsonl`，汇总在 `research/benchmark.json`。`research/manual-review.jsonl` 包含六道待独立人工复核的候选题及核验依据。项目未导入任何第三方评测样本。DPO 属于可选项，本次实现覆盖原始指令模型、提示词基线和 LoRA SFT。

## 参考与授权

原始模型采用 Apache 2.0。项目沿用模型和适配器的许可文档，字体许可见 `public/fonts/`。镜面主图为项目生成图像。

- [Qwen2.5-0.5B-Instruct](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct)
- [SycophancyEval](https://github.com/meg-tong/sycophancy-eval)
- [BertViz](https://github.com/jessevig/bertviz)
- [Multiverse](https://github.com/gfxroy/multiverse)

完成数据、适配器、回放和评测后，运行 `python -m scripts.release --data data` 更新研究下载项，再重新构建静态站点。
